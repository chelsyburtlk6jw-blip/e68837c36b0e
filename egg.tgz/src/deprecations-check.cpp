// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("deprecations check\n", stdout);
  return lionss_run_workload("deprecations-check");
}
