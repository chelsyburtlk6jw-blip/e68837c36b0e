// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("retry matrix"); }
int main(){
  announce();
  return lionss_run_workload("retry-matrix");
}
