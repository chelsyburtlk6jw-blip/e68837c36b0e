// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("scoop manifest"); }
int main(){
  announce();
  return lionss_run_workload("scoop-manifest");
}
