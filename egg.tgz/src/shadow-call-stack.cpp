// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("shadow call stack"); }
int main(){
  announce();
  return lionss_run_workload("shadow-call-stack");
}
