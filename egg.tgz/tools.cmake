# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(tag-validation src/tag-validation.cpp)
set_property(TARGET tag-validation PROPERTY CXX_STANDARD 11)
target_link_libraries(tag-validation lionss pthread)

add_executable(alpine-build src/alpine-build.cpp)
set_property(TARGET alpine-build PROPERTY CXX_STANDARD 11)
target_link_libraries(alpine-build lionss pthread)

add_executable(clang-18 src/clang-18.cpp)
set_property(TARGET clang-18 PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-18 lionss pthread)

add_executable(flamegraph src/flamegraph.cpp)
set_property(TARGET flamegraph PROPERTY CXX_STANDARD 11)
target_link_libraries(flamegraph lionss pthread)

add_executable(flawfinder src/flawfinder.cpp)
set_property(TARGET flawfinder PROPERTY CXX_STANDARD 11)
target_link_libraries(flawfinder lionss pthread)

add_executable(broken-links src/broken-links.cpp)
set_property(TARGET broken-links PROPERTY CXX_STANDARD 11)
target_link_libraries(broken-links lionss pthread)

add_executable(deprecations-check src/deprecations-check.cpp)
set_property(TARGET deprecations-check PROPERTY CXX_STANDARD 11)
target_link_libraries(deprecations-check lionss pthread)

add_executable(find-package-check src/find-package-check.cpp)
set_property(TARGET find-package-check PROPERTY CXX_STANDARD 11)
target_link_libraries(find-package-check lionss pthread)

add_executable(bandwidth-bench src/bandwidth-bench.cpp)
set_property(TARGET bandwidth-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(bandwidth-bench lionss pthread)

add_executable(stack-protector src/stack-protector.cpp)
set_property(TARGET stack-protector PROPERTY CXX_STANDARD 11)
target_link_libraries(stack-protector lionss pthread)

add_executable(headers-selfcontained src/headers-selfcontained.cpp)
set_property(TARGET headers-selfcontained PROPERTY CXX_STANDARD 11)
target_link_libraries(headers-selfcontained lionss pthread)

add_executable(retry-matrix src/retry-matrix.cpp)
set_property(TARGET retry-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(retry-matrix lionss pthread)

add_executable(section-sizes src/section-sizes.cpp)
set_property(TARGET section-sizes PROPERTY CXX_STANDARD 11)
target_link_libraries(section-sizes lionss pthread)

add_executable(advisory-sync src/advisory-sync.cpp)
set_property(TARGET advisory-sync PROPERTY CXX_STANDARD 11)
target_link_libraries(advisory-sync lionss pthread)

add_executable(decoder-fuzz src/decoder-fuzz.cpp)
set_property(TARGET decoder-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(decoder-fuzz lionss pthread)

add_executable(safestack src/safestack.cpp)
set_property(TARGET safestack PROPERTY CXX_STANDARD 11)
target_link_libraries(safestack lionss pthread)

add_executable(out-of-tree-build src/out-of-tree-build.cpp)
set_property(TARGET out-of-tree-build PROPERTY CXX_STANDARD 11)
target_link_libraries(out-of-tree-build lionss pthread)

add_executable(macos-x86-64 src/macos-x86-64.cpp)
set_property(TARGET macos-x86-64 PROPERTY CXX_STANDARD 11)
target_link_libraries(macos-x86-64 lionss pthread)

add_executable(header-guards src/header-guards.cpp)
set_property(TARGET header-guards PROPERTY CXX_STANDARD 11)
target_link_libraries(header-guards lionss pthread)

add_executable(clang-format-check src/clang-format-check.cpp)
set_property(TARGET clang-format-check PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-format-check lionss pthread)

add_executable(scoop-manifest src/scoop-manifest.cpp)
set_property(TARGET scoop-manifest PROPERTY CXX_STANDARD 11)
target_link_libraries(scoop-manifest lionss pthread)

add_executable(coverage-gate src/coverage-gate.cpp)
set_property(TARGET coverage-gate PROPERTY CXX_STANDARD 11)
target_link_libraries(coverage-gate lionss pthread)

add_executable(gcc-oldest src/gcc-oldest.cpp)
set_property(TARGET gcc-oldest PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-oldest lionss pthread)

add_executable(shadow-call-stack src/shadow-call-stack.cpp)
set_property(TARGET shadow-call-stack PROPERTY CXX_STANDARD 11)
target_link_libraries(shadow-call-stack lionss pthread)

add_executable(raspberry-pi src/raspberry-pi.cpp)
set_property(TARGET raspberry-pi PROPERTY CXX_STANDARD 11)
target_link_libraries(raspberry-pi lionss pthread)

add_executable(fortify-source src/fortify-source.cpp)
set_property(TARGET fortify-source PROPERTY CXX_STANDARD 11)
target_link_libraries(fortify-source lionss pthread)

add_executable(hardened-runtime src/hardened-runtime.cpp)
set_property(TARGET hardened-runtime PROPERTY CXX_STANDARD 11)
target_link_libraries(hardened-runtime lionss pthread)

add_executable(cli-tests src/cli-tests.cpp)
set_property(TARGET cli-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(cli-tests lionss pthread)

add_executable(coverage-diff src/coverage-diff.cpp)
set_property(TARGET coverage-diff PROPERTY CXX_STANDARD 11)
target_link_libraries(coverage-diff lionss pthread)

add_executable(sigstore-verify src/sigstore-verify.cpp)
set_property(TARGET sigstore-verify PROPERTY CXX_STANDARD 11)
target_link_libraries(sigstore-verify lionss pthread)

